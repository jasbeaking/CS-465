const express = require("express");
const path = require("path");
const hbs = require("hbs");

const app = express();
const port = 3000;

// Tell Express where views live 
app.set("views", path.join(__dirname, "app_server", "views"));
app.set("view engine", "hbs");

// Register partials
hbs.registerPartials(path.join(__dirname, "app_server", "views", "partials"));

// Serve static files 
app.use(express.static(path.join(__dirname, "public/travlr")));

// MVC routes
const appServerRoutes = require("./app_server/routes/index");
app.use("/", appServerRoutes);

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});