/* app_server/routes/index.js */

const express = require('express');
const router = express.Router();

const ctrlTravel = require('../controllers/travel');

// Home page
router.get('/', ctrlTravel.index);

// Travel page
router.get('/travel', ctrlTravel.travel);

module.exports = router;