// app_server/controllers/api/trips.js
const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

// GET /api/trips  -> return all trips as JSON
const getTrips = async (req, res) => {
  try {
    const trips = await Trip.find().lean(); // lean = plain JSON objects
    return res.status(200).json(trips);
  } catch (err) {
    console.error('Error fetching trips:', err);
    return res.status(500).json({ message: 'Server error fetching trips' });
  }
};

module.exports = {
  getTrips
};
