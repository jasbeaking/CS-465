// app_server/routes/api.js
const express = require('express');
const router = express.Router();

const tripsCtrl = require('../controllers/api/trips');

// GET /api/trips
router.get('/trips', tripsCtrl.getTrips);

module.exports = router;