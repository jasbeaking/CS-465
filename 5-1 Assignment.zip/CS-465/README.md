# CS-465
Full Stack Development

## Data Seeding

Trip data was seeded into MongoDB using the provided `trips.json` file
via MongoDB Compass. Module Five focuses on GET and FIND operations only;
insert and delete API endpoints are not required at this stage.