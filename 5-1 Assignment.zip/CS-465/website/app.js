const express = require("express");
const path = require("path");
const hbs = require("hbs");
const mongoose = require("mongoose");

// Register API models
require("./app_api/models/trips");

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1/travlr");


const app = express();
const port = 3000;

// views
app.set("views", path.join(__dirname, "app_server", "views"));
app.set("view engine", "hbs");

// Register partials
hbs.registerPartials(path.join(__dirname, "app_server", "views", "partials"));

// Serve static files 
app.use(express.static(path.join(__dirname, "public/travlr")));

// App server (frontend) routes
const appServerRoutes = require("./app_server/routes/index");
app.use("/", appServerRoutes);

app.use('/travel', require('./app_server/routes/travel'));

// API routes
const apiRoutes = require("./app_api/routes/trips");
app.use("/api", apiRoutes);

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
